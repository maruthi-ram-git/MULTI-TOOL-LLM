# Multitool — AI Answer Hub

A web app that sends one question to four differently-styled AI panels —
Perplexity-style (web search), NotebookLM-style (your own document), Consensus-style
(research synthesis), and Claude (direct) — plus a free image generator.

All four text panels are powered by the **Claude API** on the backend, each prompted
to mirror how that tool works. None of this calls the real Perplexity, NotebookLM, or
Consensus APIs — those don't offer free public APIs to build with.

```
├── app/
│   ├── __init__.py
│   ├── main.py          # FastAPI application (routes)
│   ├── config.py         # loads the API key from .env
│   └── llm.py             # one function per panel style + the Claude API calls
│
├── templates/
│   └── index.html          # page markup (Jinja2)
│
├── static/
│   ├── style.css            # all styling
│   └── script.js              # talks to the backend, drives the UI, image generation
│
├── .env                          # your real API key (not committed)
├── .env.example                   # template for the above
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. Get a free API key

1. Go to https://console.anthropic.com and create an account.
2. New accounts get a small amount of free trial credit — enough for a college
   project demo, but not unlimited, so don't hammer it in a loop.
3. Create an API key under **API Keys**.

## 2. Set up the project

```bash
# from inside this folder
python -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env            # then open .env and paste your key in
```

Your `.env` should look like:

```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxx
MODEL_NAME=claude-sonnet-4-6
```

## 3. Run it

```bash
uvicorn app.main:app --reload
```

Open **http://localhost:8000** in your browser — works on desktop, and on your
phone/tablet if they're on the same Wi-Fi (use your computer's local IP instead
of `localhost`, e.g. `http://192.168.1.23:8000`).

## Notes

- The API key stays on the server (in `.env`) and is never sent to the browser —
  this is safer than putting a key directly in frontend JavaScript.
- The image generator (`static/script.js`) calls Pollinations.ai directly from the
  browser — it needs no API key and isn't rate-limited by your Claude credits.
- `.env` is listed in `.gitignore` — never commit your real API key. Share
  `.env.example` instead if you push this to GitHub.
- If a panel shows an error message, check the terminal running `uvicorn` — it will
  usually show the real error (often a missing/invalid API key or no credit left).

## Deploying it for free (optional)

Free static hosts (GitHub Pages, Netlify) can't run a Python backend. For a live
public link, use a free tier on something that runs Python, like Render.com or
Railway.app — add `ANTHROPIC_API_KEY` as an environment variable in their dashboard
instead of committing `.env`.
