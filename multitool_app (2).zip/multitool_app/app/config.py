"""
Loads configuration (API key, model name) from environment variables / .env file.
"""
import os
from dotenv import load_dotenv

load_dotenv()

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
MODEL_NAME = os.getenv("MODEL_NAME", "claude-sonnet-4-6")

if not ANTHROPIC_API_KEY:
    print(
        "[warning] ANTHROPIC_API_KEY is not set. "
        "Copy .env.example to .env and add your key from console.anthropic.com"
    )
