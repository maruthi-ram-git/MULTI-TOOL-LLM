import asyncio
from typing import Optional

from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.llm import (
    ask_claude,
    ask_perplexity_style,
    ask_notebooklm_style,
    ask_consensus_style,
    summarize,
)

app = FastAPI(title="Multitool")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request, "index.html")


@app.post("/api/ask")
async def api_ask(
    question: str = Form(...),
    document: Optional[UploadFile] = File(None),
):
    document_text = None
    document_name = None
    if document is not None and document.filename:
        raw = await document.read()
        document_text = raw.decode("utf-8", errors="ignore")
        document_name = document.filename

    loop = asyncio.get_event_loop()

    # Run all four model calls concurrently in a thread pool
    search_answer, doc_answer, research_answer, claude_answer = await asyncio.gather(
        loop.run_in_executor(None, ask_perplexity_style, question),
        loop.run_in_executor(None, ask_notebooklm_style, question, document_text, document_name),
        loop.run_in_executor(None, ask_consensus_style, question),
        loop.run_in_executor(None, ask_claude, question),
    )

    answers = {
        "Perplexity": search_answer,
        "NotebookLM": doc_answer,
        "Consensus": research_answer,
        "Claude": claude_answer,
    }
    summary = await loop.run_in_executor(None, summarize, question, answers)

    return {
        "search": search_answer,
        "doc": doc_answer,
        "research": research_answer,
        "claude": claude_answer,
        "summary": summary,
        "document_name": document_name,
    }
