"""
All calls to the Claude API live here. Each function prompts Claude to behave
like a different tool (Perplexity, NotebookLM, Consensus) or answer directly.
None of these call the real third-party APIs -- they are Claude, styled.
"""
from typing import Optional
from anthropic import Anthropic
from app.config import ANTHROPIC_API_KEY, MODEL_NAME

client = Anthropic(api_key=ANTHROPIC_API_KEY)


def _extract_text(message) -> str:
    parts = [block.text for block in message.content if block.type == "text"]
    return "\n".join(parts).strip() or "(no response text returned)"


def ask_claude(question: str) -> str:
    """Direct answer -- Claude answering as itself."""
    try:
        message = client.messages.create(
            model=MODEL_NAME,
            max_tokens=500,
            messages=[{
                "role": "user",
                "content": f"Answer clearly and conversationally in under 110 words: {question}",
            }],
        )
        return _extract_text(message)
    except Exception:
        return "Couldn't reach Claude right now. Please try again."


def ask_perplexity_style(question: str) -> str:
    """Web-search-grounded answer, mirroring Perplexity's approach."""
    try:
        message = client.messages.create(
            model=MODEL_NAME,
            max_tokens=500,
            messages=[{
                "role": "user",
                "content": (
                    f"Search the web and answer this question in under 110 words, "
                    f"in plain conversational language: {question}"
                ),
            }],
            tools=[{"type": "web_search_20250305", "name": "web_search"}],
        )
        return _extract_text(message)
    except Exception:
        return "Couldn't reach the search-grounded model right now. Please try again."


def ask_notebooklm_style(
    question: str,
    document_text: Optional[str],
    document_name: Optional[str],
) -> str:
    """Document-grounded answer, mirroring NotebookLM's approach."""
    if not document_text:
        return (
            "Attach a .txt or .md file, then ask again -- this panel only answers "
            "from your uploaded document."
        )
    try:
        clipped = document_text[:12000]
        prompt = (
            f'Document "{document_name}":\n"""\n{clipped}\n"""\n\n'
            f"Using only the document above, answer this question in under 110 words: {question}\n"
            "If the document does not contain the answer, say so plainly instead of guessing."
        )
        message = client.messages.create(
            model=MODEL_NAME,
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        return _extract_text(message)
    except Exception:
        return "Couldn't read the document right now. Please try again."


def ask_consensus_style(question: str) -> str:
    """Simulated research synthesis, mirroring Consensus's academic framing.
    There is no live scholarly database connected -- this is disclosed to the user."""
    try:
        prompt = (
            "You do not have access to a live scholarly paper database. Give a general, "
            "research-informed answer to this question in under 100 words, written in an "
            "academic/synthesis tone (as if summarizing what research broadly suggests), "
            f"without inventing specific study names or citations: {question}"
        )
        message = client.messages.create(
            model=MODEL_NAME,
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        return _extract_text(message)
    except Exception:
        return "Couldn't generate a research synthesis right now. Please try again."


def summarize(question: str, answers: dict) -> Optional[str]:
    """One extra call that compares the four answers in 2 sentences."""
    valid = {
        k: v for k, v in answers.items()
        if v and not v.startswith("Couldn't") and not v.startswith("Attach a")
    }
    if len(valid) < 2:
        return None
    try:
        combined = "\n\n".join(f"{k}: {v}" for k, v in valid.items())
        prompt = (
            f'Here are several different answers to the question "{question}":\n\n{combined}\n\n'
            "In exactly 2 short sentences, describe how these answers compare or where they "
            "agree/differ. Do not repeat the answers themselves."
        )
        message = client.messages.create(
            model=MODEL_NAME,
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}],
        )
        return _extract_text(message)
    except Exception:
        return None
