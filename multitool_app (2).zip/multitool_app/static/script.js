const TOOLS = [
  { key:'search',   name:'Perplexity', tag:'web-grounded',    color:'var(--teal)',   icon:'P' },
  { key:'doc',      name:'NotebookLM', tag:'source-grounded', color:'var(--amber)',  icon:'N' },
  { key:'research', name:'Consensus',  tag:'simulated',       color:'var(--violet)', icon:'Co' },
  { key:'claude',   name:'Claude',     tag:'direct',          color:'var(--clay)',   icon:'C' },
];

let uploadedFile = null;

const resultsGrid = document.getElementById('resultsGrid');
const summaryBox = document.getElementById('summaryBox');
const summaryText = document.getElementById('summaryText');
const askBtn = document.getElementById('askBtn');
const questionInput = document.getElementById('questionInput');
const fileInput = document.getElementById('fileInput');
const fileNameEl = document.getElementById('fileName');
const clearFileBtn = document.getElementById('clearFile');

function buildCards(){
  resultsGrid.innerHTML = '';
  TOOLS.forEach(t=>{
    const card = document.createElement('div');
    card.className = 'card';
    card.style.setProperty('--accent-color', t.color);
    card.innerHTML = `
      <div class="card-head">
        <div class="tool-icon">${t.icon}</div>
        <div class="tool-name">${t.name}</div>
        <div class="tool-tag">${t.tag}</div>
      </div>
      <div class="card-body muted" id="body-${t.key}">Ask a question to see an answer here.</div>
      <div class="card-foot" id="foot-${t.key}"></div>
    `;
    resultsGrid.appendChild(card);
  });
}
buildCards();

fileInput.addEventListener('change', (e)=>{
  const f = e.target.files[0];
  if(!f) return;
  uploadedFile = f;
  fileNameEl.textContent = f.name;
  clearFileBtn.style.display = 'inline';
});
clearFileBtn.addEventListener('click', ()=>{
  uploadedFile = null;
  fileInput.value = '';
  fileNameEl.textContent = '';
  clearFileBtn.style.display = 'none';
});

function setLoading(key){
  document.getElementById('body-' + key).innerHTML = '<div class="spinner"></div>';
  document.getElementById('body-' + key).classList.remove('muted');
  document.getElementById('foot-' + key).textContent = '';
}
function setResult(key, text, foot){
  const el = document.getElementById('body-' + key);
  el.textContent = text;
  el.classList.remove('muted');
  document.getElementById('foot-' + key).textContent = foot || '';
}

async function askAll(){
  const question = questionInput.value.trim();
  if(!question) return;

  askBtn.disabled = true;
  summaryBox.style.display = 'none';
  TOOLS.forEach(t => setLoading(t.key));

  const formData = new FormData();
  formData.append('question', question);
  if(uploadedFile) formData.append('document', uploadedFile);

  try{
    const res = await fetch('/api/ask', { method:'POST', body: formData });
    if(!res.ok) throw new Error('Server error ' + res.status);
    const data = await res.json();

    setResult('search', data.search, 'Grounded with a live web search.');
    setResult('doc', data.doc, data.document_name ? `Grounded in ${data.document_name}.` : '');
    setResult('research', data.research, 'Simulated synthesis — no live paper database connected.');
    setResult('claude', data.claude, 'Direct model answer.');

    if(data.summary){
      summaryText.textContent = data.summary;
      summaryBox.style.display = 'flex';
    }
  }catch(err){
    TOOLS.forEach(t => setResult(t.key, "Couldn't reach the server right now. Please check it's running and try again.", ''));
  }finally{
    askBtn.disabled = false;
  }
}

askBtn.addEventListener('click', askAll);
questionInput.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') askAll(); });

/* ---------------- Mode switching ---------------- */
const modeAskBtn = document.getElementById('modeAskBtn');
const modeImageBtn = document.getElementById('modeImageBtn');
const askMode = document.getElementById('askMode');
const imageMode = document.getElementById('imageMode');

modeAskBtn.addEventListener('click', ()=>{
  modeAskBtn.classList.add('active');
  modeImageBtn.classList.remove('active');
  askMode.style.display = 'block';
  imageMode.style.display = 'none';
});
modeImageBtn.addEventListener('click', ()=>{
  modeImageBtn.classList.add('active');
  modeAskBtn.classList.remove('active');
  imageMode.style.display = 'block';
  askMode.style.display = 'none';
});

/* ---------------- Image generation (no backend needed, no key needed) ---------------- */
const imagePromptInput = document.getElementById('imagePrompt');
const imageBtn = document.getElementById('imageBtn');
const genImage = document.getElementById('genImage');
const imagePlaceholder = document.getElementById('imagePlaceholder');
const imageActions = document.getElementById('imageActions');
const regenBtn = document.getElementById('regenBtn');
const downloadBtn = document.getElementById('downloadBtn');

function generateImage(){
  const prompt = imagePromptInput.value.trim();
  if(!prompt) return;
  imagePlaceholder.textContent = 'Generating…';
  imagePlaceholder.style.display = 'flex';
  genImage.style.display = 'none';
  imageActions.style.display = 'none';

  const seed = Math.floor(Math.random() * 1000000);
  const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=768&height=768&nologo=true&seed=${seed}`;

  genImage.onload = ()=>{
    imagePlaceholder.style.display = 'none';
    genImage.style.display = 'block';
    imageActions.style.display = 'flex';
    downloadBtn.href = url;
  };
  genImage.onerror = ()=>{
    imagePlaceholder.textContent = "Couldn't generate the image right now. Please try again.";
  };
  genImage.src = url;
}

imageBtn.addEventListener('click', generateImage);
imagePromptInput.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') generateImage(); });
regenBtn.addEventListener('click', generateImage);
